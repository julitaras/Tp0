#include "tp0.h"
#include <stdio.h>

/* *****************************************************************
 *                     FUNCIONES A COMPLETAR                       *
 *         (ver en tp0.h la documentación de cada función)         *
 * *****************************************************************/

void swap (int *x, int *y) {
    int aux = *x;
    *x = *y;
    *y = aux;
}


int maximo(int vector[], int n) {
    int i = 0;
    int pos = 0;

    if(n == 0) {
        pos = -1;
    } else {
        if(n == 1) {
            pos = 0;
        } else {
            for(i = 1; i < n; i++){    
                if(vector[i] > vector[pos]){
                    // max = vector[i];
                    pos = i;
                }
            }
        }
    }

    return pos;
}

int comparar(int vector1[], int n1, int vector2[], int n2) {
    if(vector1 == NULL && vector2 == NULL) {
        return 0;
    }else{
        if(vector1 != NULL && vector2 != NULL) {
            int i = 0;
            
            while (i < n1 && i < n2) {
                if(vector1[i] == vector2[i]) {
                    i++;
                } else {
                    if(vector1[i] < vector2[i]) {
                        return -1;
                    } else {
                        return 1;
                    }
                }
            }

            if(n1 <= i) {
                if(n2 > i) {
                    return -1;
                } else {
                    return 0;
                }
            }

            if(n2 <= i) {
                if(n1 > i) {
                    return 1;
                } else {
                    return 0;
                }
            }
        }else{
            return -1;
        }
    }
}
void seleccion(int vector[], int n) {
    int i;
    for(i = 0; i < n; i++){
        int cotaMayor = n - i;
        int maxRestante = maximo(vector, cotaMayor);
        swap(&vector[maxRestante], &vector[cotaMayor - 1]);
    }
}